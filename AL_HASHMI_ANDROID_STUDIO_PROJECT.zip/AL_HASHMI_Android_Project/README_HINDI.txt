AL HASHMI JHUBBA HOUSE — ANDROID APP PROJECT

IMPORTANT:
This is an Android Studio project, not a compiled APK file. This workspace does not have the Android SDK/build tools needed to compile and sign an APK here.

If you have a laptop/computer:
1. Install Android Studio from https://developer.android.com/studio
2. Extract this ZIP.
3. Open Android Studio > Open > choose the extracted AL_HASHMI_Android_Project folder.
4. Wait for Gradle sync.
5. Connect Android phone with USB debugging enabled, or use an emulator, then press Run.
6. To build an APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
7. Android Studio will show where the APK is saved.

The app opens the included storefront locally and keeps the logo intro animation. WhatsApp checkout requires internet and WhatsApp (or a compatible browser).

If you only have a phone, tell the assistant. This project needs a computer/Android build environment to produce an APK; do not upload this source ZIP to Netlify expecting an APK.
